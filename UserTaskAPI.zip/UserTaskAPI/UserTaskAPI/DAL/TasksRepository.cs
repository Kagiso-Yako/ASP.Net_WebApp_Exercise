﻿using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Microsoft.Build.Framework;
using UserTaskAPI.Models;
using System.Linq.Expressions;

namespace UserTaskAPI.DAL
{
    public class TasksRepository: IRepository<TaskSet>
    {
        private readonly UsersTasksContext _context;
        private readonly DbSet<TaskSet> _DBSet;

        public TasksRepository(UsersTasksContext context)
        {
            _context = context;
            _DBSet = context.Set<TaskSet>();
        }

        public TaskSet GetItem(string id)
        {
            var task = _context.TaskSet.Find(id);
            
            return task;
        }
        public void Create(TaskSet task)
        {
            _context.Add(task);
        }
        public void Update(TaskSet task) {
            _context.Update(task);
            save_Changes();

        }

        public async void save_Changes()
        {
            try
            {
                await _context.SaveChangesAsync();
            }
            catch
            {
               
            }
        }

        public bool TasksIsNull()
        {
            if (_context.TaskSet == null || _context.TaskSet.Count() == 0)
                return true;
            return false;
        }

        public bool containsItem(string id)
        {
            if (_context.Users.Find(id) != null)
            {
                return true;
            }
            return false;
        }

        public async void Delete(string id) 
        {
            var tasks = await _context.TaskSet.FindAsync(id);
            if (tasks != null)
            {
                _context.TaskSet.Remove(tasks);
            }

            save_Changes();
        }
    }
}
