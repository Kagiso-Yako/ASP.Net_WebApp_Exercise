﻿using Microsoft.EntityFrameworkCore;

using System.Threading.Tasks;
using Microsoft.Build.Framework;
using UserTaskAPI.Models;

namespace UserTaskAPI.DAL
{
    public class UsersRepository : IRepository<Users> 
    {
        private readonly UsersTasksContext _context;
        private readonly DbSet<Users> _DBSet;

        public UsersRepository(UsersTasksContext context)
        {
            _context = context;
            _DBSet = context.Set<Users>();
        }

        public Users GetItem(string id)
        {
            var user = _context.Users.Find(id);

            return user;
        }
        public void Create(Users user)
        {
            _context.Add(user);
            save_Changes();
        }
        public void Update(Users user)
        {
            _context.Entry(user).State = EntityState.Modified;
            save_Changes();

        }

        public async void save_Changes()
        {
            await _context.SaveChangesAsync();
        }

        public bool containsItem(string id)
        {
            if (_context.Users.Find(id) != null)
            {
                return true;
            }
            return false;
        }

        public bool UsersIsNull()
        {
            if (_context.Users == null || _context.Users.Count() == 0)
                return true;
            return false;
        }

        public async void Delete(string id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user != null)
            {
                _context.Users.Remove(user);
            }
            save_Changes();
        }
    }
}
