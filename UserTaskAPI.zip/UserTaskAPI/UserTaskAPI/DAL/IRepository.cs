﻿using System.Collections.Generic;
using UserTaskAPI.Models;

namespace UserTaskAPI.DAL
{
    public interface IRepository<T>
    {
        T GetItem(string id);
        void Create(T Task);
        void Update(T Task);
        void Delete(string id);
    }
}
