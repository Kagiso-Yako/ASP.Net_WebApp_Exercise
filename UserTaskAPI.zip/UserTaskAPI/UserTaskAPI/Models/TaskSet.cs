﻿using System.ComponentModel.DataAnnotations;

namespace UserTaskAPI.Models
{
    public class TaskSet
    {
        [Key]
        public string ? ID { get; set; }
        
        public string ? Title { get; set; }
        public string ? Description { get; set; }

        // Assignee works as foreign key
        public string ? Assignee { get; set; }
        public string ? DueDate { get; set; }
    }
}
