﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace UserTaskAPI.Models
{
    public class UsersTasksContext : DbContext
    {
        public UsersTasksContext(DbContextOptions<UsersTasksContext> options) : base(options) { }

         public DbSet <Users> Users {
            get;
            set;
        }
        public  DbSet<TaskSet> TaskSet
        {
           get;
           set;
        }




    }
}
