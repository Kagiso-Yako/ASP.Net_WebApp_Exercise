﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using UserTaskAPI.Models;
using UserTaskAPI.DAL;

namespace UserTaskAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : Controller
    {
        private TasksRepository _repo;

        public TasksController(UsersTasksContext _context)
        {
            _repo = new TasksRepository(_context);
        }

        // GET: Tasks1/Details/5
        [HttpGet("GetRecord/{id}")]
        public IActionResult Details(string id)
        {
            if (id == null || _repo.TasksIsNull())
            {
                return NotFound();
            }


            return View("/Views/Tasks1/Details.cshtml", _repo.GetItem(id));
        }

        // POST: Tasks1/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Create")]
        public IActionResult Create([FromBody] TaskSet task)
        {
            if (task != null && task.ID != null) { 
                if ((ModelState.IsValid) && (_repo.containsItem(task.ID) == false))
                {
                    _repo.Create(task);
                    _repo.save_Changes();
                    return View("/Views/Tasks1/Create.cshtml", _repo.GetItem(task.ID));
                }
            }
            return BadRequest();
        }

        // POST: Tasks1/Edit//
        [HttpPost("Update/{id}")]
        public IActionResult Edit(string id, [FromBody] TaskSet tasks)
        {
            if (id != tasks.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _repo.Update(tasks);
            }
            return Ok();
        }

        // GET: Tasks1/Delete/5
        [HttpGet("Delete/{id}")]
        public IActionResult Delete(string id)
        {
            if (id == null || _repo.TasksIsNull())
            {
                return NotFound();
            }
            _repo.Delete(id);

            return Ok();
        }
    }
}
