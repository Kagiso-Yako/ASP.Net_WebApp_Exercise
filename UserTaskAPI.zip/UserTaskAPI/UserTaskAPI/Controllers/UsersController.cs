﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MessagePack;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Build.Framework;
using Microsoft.EntityFrameworkCore;
using UserTaskAPI.DAL;
using UserTaskAPI.Models;

namespace UserTaskAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : Controller
    {
        private UsersRepository _repo;

        public UsersController(UsersTasksContext _context)
        {
            _repo = new UsersRepository(_context);
        }

        // GET: Users1/Details/5
        [HttpGet("GetRecord/{id}")]
        public ActionResult Details(string id)
        {
            if (id == null || _repo.UsersIsNull())
            {
                return NotFound();
            }

            return View("/Views/Users1/Details.cshtml", _repo.GetItem(id));
        }

        // POST: Users1/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Create")]
        public IActionResult Create([FromBody] Users users)
        {
            if (users != null && users.ID != null)
            {
                if ((ModelState.IsValid) && (_repo.containsItem(users.ID) == false))
                {
                    _repo.Create(users);
                    _repo.save_Changes();
                    return View("/Views/Tasks1/Create.cshtml", _repo.GetItem(users.ID));
                }

            }

            return BadRequest();
        }

        // POST: Users1/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost("Update/{id}")]
        public IActionResult Edit(string id, [FromBody] Users users)
        {
            if (id != users.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _repo.Update(users);
            }
            return View("Views/Users1/Edit.cshtml");
        }

        // GET: Users1/Delete/5
        [HttpGet("Delete/{id}")]
        public ActionResult Delete(string id)
        {
            if (id == null || _repo.UsersIsNull())
            {
                return NotFound();
            }
            _repo.Delete(id);
            return View("Views/Users1/Delete.cshtml");
        }
    }

} 
